// script.js — Funciones de la Parte II del examen
// 1) Reordenar columnas a filas
const btnStack = document.getElementById('btn-stack');
const cities = document.getElementById('cities');
btnStack.addEventListener('click', () => {
  cities.classList.toggle('stacked');
  btnStack.textContent = cities.classList.contains('stacked')
    ? 'Ordenar filas → columnas'
    : 'Ordenar columnas → filas';
});

// 2) Cambiar título del header
const btnTitle = document.getElementById('btn-title');
const siteTitle = document.getElementById('site-title');
btnTitle.addEventListener('click', () => {
  siteTitle.textContent = 'HTML & CSS: Curso práctico avanzado';
});

// 3) Cambiar colores de títulos y textos de las secciones
const btnColors = document.getElementById('btn-colors');
btnColors.addEventListener('click', () => {
  document.body.classList.toggle('theme-alt');
});

// 4) Agregar imagen al Footer (desde URL o archivo local)
const btnFooterImg = document.getElementById('btn-footer-img');
const footerImageUrl = document.getElementById('footerImageUrl');
const footerImageFile = document.getElementById('footerImageFile');
const footerImageContainer = document.getElementById('footerImageContainer');

btnFooterImg.addEventListener('click', async () => {
  // Prioridad: si hay archivo local seleccionado, úsalo; si no, intenta con URL
  if (footerImageFile.files && footerImageFile.files[0]) {
    const file = footerImageFile.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      appendFooterImage(e.target.result);
    };
    reader.readAsDataURL(file);
  } else if (footerImageUrl.value.trim() !== '') {
    appendFooterImage(footerImageUrl.value.trim());
  } else {
    // Si no se provee nada, usamos una imagen de ejemplo (Unsplash)
    appendFooterImage('https://images.unsplash.com/photo-1509021436665-8f07dbf5bf1d?q=80&w=800&auto=format&fit=crop');
  }
});

function appendFooterImage(src) {
  const img = document.createElement('img');
  img.src = src;
  img.alt = 'Imagen agregada al footer';
  footerImageContainer.appendChild(img);
  // Limpia inputs para la siguiente acción
  footerImageUrl.value = '';
  footerImageFile.value = '';
}
